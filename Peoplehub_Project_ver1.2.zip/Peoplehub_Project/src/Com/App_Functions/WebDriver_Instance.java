package Com.App_Functions;

import Com.App_Functions.Properties_Read;
import Com.App_Functions.Logging;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

public class WebDriver_Instance {

	static SoftAssert softassert = new SoftAssert();
	static String _locale = null;
	static WebDriver _driver = null;
	static String _browser = null;
	static String _chromeWebDriverPath;
	static String _ieWebDriverPath;
	public static WebDriver _ieDriver = null;
	public static WebDriver _chromeDriver = null;
    static String localisation = null; 
	// http://127.0.0.1:4444/wd/hub
	@Parameters({"localisation"})
    @BeforeSuite(groups={"smoke" ,"functional"})
	public void setTheWebDriverPath(String local) throws IOException {

		try {
            localisation = local;			
			Properties_Read pr = new Properties_Read();
			_chromeWebDriverPath = pr.propertyRead("./configs//Configuration.properties")
					.getProperty("chromeWebDriver");
			Logging.getTheLogForPropertyFileRead("Chrome web driver path is retrieved",
					"Chrome web driver path is not retrieved", _chromeWebDriverPath);
			_ieWebDriverPath = pr.propertyRead("./configs//Configuration.properties").getProperty("ieWebDriver");
			Logging.getTheLogForPropertyFileRead("Internet explorer web driver path is retrieved",
					"Internet explorer web driver path is not retrieved", _ieWebDriverPath);
		} catch (FileNotFoundException e) {
                Logging.getTheLogForFailureMessage("Properties file not found");
		}
	}
	@Parameters({"browser"})
    @BeforeTest
    public void selectTheBrowser(String browser){
    	_browser = browser;
    }
	/*
	 * private WebDriver_Instance() {
	 * 
	 * System.out.println("Instance of the Singleton Class created"); }
	 */
 // need to remove the String browser parameter from the below method
	public static void setTheLocale(String locale){
		_locale = locale;
	} 
	public static  WebDriver getDriverInstance(/*String browser*/) throws MalformedURLException {
		//if (_chromeDriver == null && browser.equals("Chrome")) {
		if (_chromeDriver == null && _browser.equals("Chrome")) {
			// System.out.println("chrome driver path:
			// "+_chromeWebDriverPath);
			// System.setProperty("webdriver.chrome.driver",
			// "C://Users//M1052416//Downloads//chromedriver_win32//chromedriver.exe");
			System.setProperty("webdriver.chrome.driver", _chromeWebDriverPath);
			DesiredCapabilities dc = DesiredCapabilities.chrome();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("start-maximized");
			options.addArguments("dsable-extensions");
			if(localisation.equals("yes")){				
			Map<String,String> prefs = new HashMap<String,String>();
			prefs.put("intl.accept_languages",_locale);
			options.setExperimentalOption("prefs", prefs);
			}
			dc.setCapability(ChromeOptions.CAPABILITY, options);
			// chromeDriver = new ChromeDriver(options);
			try {
				_chromeDriver = new RemoteWebDriver(new URL("http://127.0.0.1:4444/wd/hub"), dc);
				_driver = _chromeDriver;
			} 
			catch (UnreachableBrowserException e) {
				Logging.getTheLogForFailureMessage("unreachable "+ _browser + " browser exception");
				e.getMessage();
			}
		} //else if (_ieDriver == null && browser.equals("InternetExplorer")) {
		else if (_ieDriver == null && _browser.equals("InternetExplorer")) {
			// System.setProperty("webdriver.ie.driver",
			// "C://Users//M1052416//Downloads//IEDriverServer_x64_2.51.0//IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", _ieWebDriverPath);
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability("requireWindowFocus", true);
			capabilities.setCapability("ignoreZoomSetting", true);
			// ieDriver = new InternetExplorerDriver(capabilities);
			// ieDriver.manage().window().maximize();
			try {

				_ieDriver = new RemoteWebDriver(new URL("http://127.0.0.1:4444/wd/hub"), capabilities);
				_driver = _ieDriver;
			}
			catch (UnreachableBrowserException e) {
				Logging.getTheLogForFailureMessage("unreachable "+ _browser + " browser exception");
				e.getMessage();

			}

		}
		return _driver;
	}

}
