package Com.PeopleHub_Interface;

import java.io.IOException;

public interface Class1_Interface {
	
	public void getTheProperty() throws IOException;
	public void orgatakeSrcImageCES(String browser) throws IOException;
	public void orgbImmersiveAurora(String browser, String src, String attribute, String pageurl)
	throws IOException;

}
